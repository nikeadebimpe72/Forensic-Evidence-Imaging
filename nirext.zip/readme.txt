


NirExt v1.01
Copyright (c) 2003 - 2004 Nir Sofer



Description
===========

The NirExt utility add 3 useful context menu extensions to your Windows
Explorer environment:
* Folder Properties: This option is available in the context menu when
  you right-click on a folder in your file system. It allows you change
  the icon of any folder you want, and change the text that appears when
  the mouse cursor moves over the folder.
* Advanced Run: This option is available in the context menu when you
  right-click on an executable file (*.EXE). It allows you to instantly
  run an application with command-line and some other options.
* Create Shortcut+: This option is available in the context menu when
  you right-click on any file in your system. It allows you to instantly
  create a shortcut and drop it into one of the following folders:
  Desktop, Start Menu, Programs folder under Start Menu, Common Desktop
  (for all users), Common Start Menu (for all users), and Common Programs
  folder (for all users) under Start Menu.



Versions History
================


* Version 1.01 - Fixed bug: NirExt now works properly if you run it
  from command-line window.
* Version 1.00 - First Release.



System Requirements
===================

This utility can work in all 32-bit Windows operating systems: Windows
9x, Windows NT, Windows 2000, and Windows XP. In very old systems
(Windows 95/Windows NT), Internet Explorer (version 4.x or above) must be
installed.



License
=======

This utility is released as freeware for personal and non-commercial use.
You are allowed to freely distribute this utility via floppy disk,
CD-ROM, Internet, or in any other way, as long as you don't charge
anything for this. If you distribute this utility, you must include all
files in the distribution package, without any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Using NirExt
============

In order to start using the NirExt utility, run the executable file
(nirext.exe), select the menu extension that you want to install (by
default, all options are selected) and press 'OK'. Whenever you want to
remove the menu extensions from your system, simply run NirExt again and
select the "Remove all context menu extensions".

Here's a little explanation about each menu extension:

* Folder Properties: This option is available in the context menu when
  you right-click on a folder in your file system.
  It allows you change the icon of any folder in your file system, and
  change the text that appears when the mouse cursor moves over the
  folder (the "Comment" field). In order to change the icon of a folder,
  click the "Select Icon" button. If you want to select an icon from EXE
  or DLL file, select the file that contains the icon you want to use,
  and then in the bottom icons list, select the desired icon and click
  the "Open" button. If you want to select an icon from .ICO file, simply
  select the ICO file and click the "Open" button.
  Whenever you want to remove the icons and other properties from the
  folder, and turn it back to a regular folder, click the "Remove Folder
  Properties" button.

  In the following screenshot, you can see an example of folders with
  different icons:


* Advanced Run: This option is available in the context menu when you
  right-click on an executable file (*.EXE). You can use this option to
  instantly run an application with command-line arguments and some other
  options.
  Here's a little description for each field:
  o Command-Line: Command-Line arguments for the application. If you
    don't want to run the application with command-line options, you can
    simply leave it blank.
  o Start in folder: Working folder for the application that you want
    to run. In most cases, you can leave it blank.
  o Window: Specifies how to display the main window of the
    application: Normal, Maximized, Minimized or Hidden.
  o Priority: Specifies the priority level for the application you
    run. For most applications, you should select the Normal Priority.
    However, if you have a very critical application that need a better
    priority over the other applications, you can try to run it with high
    priority.

* Create Shortcut+: This option is available in the context menu when
  you right-click on any file in your system. It allows you to instantly
  create a shortcut and drop it into one of the following folders:
  Desktop, Start Menu, Programs folder under Start Menu, Common Desktop
  (for all users), Common Start Menu (for all users), and Common Programs
  folder (for all users) under Start Menu. You can also specify a
  command-line options for the application, working folder, and the
  comment that appears when the mouse cursor moves over the shortcut. If
  you create a shortcut to executable file (.EXE), the description
  information from the executable file is automatically copied to the
  Shortcut Name field.




Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to nirsofer@yahoo.com


